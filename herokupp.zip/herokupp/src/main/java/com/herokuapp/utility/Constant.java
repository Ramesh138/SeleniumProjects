package com.herokuapp.utility;

public class Constant {
	
	 public static final String URL = "http://z011615:NEWJAN20@the-internet.herokuapp.com/";
}
